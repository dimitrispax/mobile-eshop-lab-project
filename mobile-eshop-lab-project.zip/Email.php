<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

$mail = new PHPMailer(true);
try {
    //SMTP Config
    $mail->SMTPDebug = 2;
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'diepafi123@gmail.com';
    $mail->Password = 'D!$p@f!123';
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    //Recepients
    $mail->setFrom('diepafi123@gmail.com', 'yo yo');
    $mail->addAddress('mitsosrock1@gmail.com');
    $mail->addReplyTo('mitsosrock1@gmail.com');

    //Content
    $mail-> isHTML(true);
    $mail->Subject = 'My first Gmail SMTP email';
    $mail->Body = 'Hi bitch! <b>POUTSA!</b>';
    
    $mail->send();
    echo 'Message has bee sent!';
} catch(Exception $e) {
    echo 'Message could not be sent. Error: ', $mail->ErrorInfo;
}


?>