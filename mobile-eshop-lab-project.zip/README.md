# mobile-eshop-lab-project
E-shop for mobile devices is a project for our lab needs.
